export function getMedicineAPI() {
  return fetch("http://localhost:8000/Medicine", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  })
    .then((res) => res.json())
    .then((data) => data);
}

export function getPatientAPI() {
  return fetch("http://localhost:8000/Patient", {
    method: "GET",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
  })
    .then((res) => res.json())
    .then((data) => data);
}
