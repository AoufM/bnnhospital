import Footer from "../components/Footer";
import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import styled from "styled-components";

const articles = () => {
  return (
    <>
      <Navbar />
      <Announcement>
        <HeroSection
          category="Announcement"
          description="No roaming in campus on 14th February"
          url="#"
        />
        <HeroSection
          category="Word"
          description="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
          url="#"
        />
        <HeroSection
          category="Sentence"
          description="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
          url="#"
        />
      </Announcement>
      <Footer />
    </>
  );
};

export default articles;

const Announcement = styled.div`
  .heroCard {
    :nth-child(1) {
      background-color: #fb5353;
      color: #fff;
    }
  }
`;
